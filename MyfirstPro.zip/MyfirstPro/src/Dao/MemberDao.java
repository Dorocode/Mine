/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import MyConnection.myConnection;
import java.util.ArrayList;
import java.util.List;
import myfirstpro.Members;

public class MemberDao extends myConnection {
   public MemberDao(){
        Connect();
        try{
            st=con.createStatement();
            String sql="CREATE TABLE if not exists myfirst("
                    + "id int PRIMARY KEY,"
                    + "firstname varchar(15),"
                    + "lastname varchar(15));";
           st.executeUpdate(sql);
           
        }catch(Exception ex){
         ex.printStackTrace();
        }finally{
            disconnect();
        }
    }
   public void insertMember(Members m){
       Connect();
       try{
           pst=con.prepareStatement("INSERT INTO myfirst values(?,?,?);");
           pst.setInt(1, m.getId());
           pst.setString(2, m.getFname());
           pst.setString(3, m.getLname());
       pst.executeUpdate();
       }catch(Exception ex){
        ex.printStackTrace();
       }finally{
           disconnect();
       }
   }
   public void deleteMember(int id){
       Connect();
       try{
           pst=con.prepareStatement("DELETE FROM myfirst where id=?");
           pst.setInt(1, id);
           pst.executeUpdate();
       }catch(Exception ex){
           ex.printStackTrace();
       }finally{
           disconnect();
       }
   }
    public List<Members> listMember(){
        List<Members> member=new ArrayList<>();
        Connect();
        try{
            st=con.createStatement();
            String ret="SELECT * FROM myfrist";
            rlt= st.executeQuery(ret);
            while(rlt.next()){
                Members mem= new Members();
                mem.setId(rlt.getInt(1));
                mem.setFname(rlt.getString(2));
                mem.setLname(rlt.getString(3));
                member.add(mem);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            disconnect();
        }
        return member;
    }
}
