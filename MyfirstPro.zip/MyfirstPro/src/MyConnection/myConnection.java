/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Mugara Steven
 */
public class myConnection extends myfirstpro.MyfirstPro {
   protected Connection con= null;
   protected Statement st=null;
   protected ResultSet rlt=null;
   protected PreparedStatement pst=null;
   
   private String url="jdbc:mysql://localhost:3306/mydb?zeroDateTimeBehavior=convertToNull";
   private String user="root";
   private String pss="";
    
    public void Connect(){
      try{
        con=DriverManager.getConnection(url, user, pss);
        System.out.println("Connection successfully!!!");
      }catch(Exception ex){
          ex.printStackTrace();
      }
    }
    public void disconnect(){
       try{
        if(con!=null){
          con.close();
        }
        if(st!=null){
          st.close();
        }
        if(rlt!=null){
         rlt.close();
        }
        if(pst!=null){
         pst.close();
        }
       }catch(Exception ex){
        ex.printStackTrace();
       }
    }
}
